element.addEventListener(type,eventListener);
function clickHandler(event) {
   console.log('Button Clicked');
}
